"""obstacle evasion state machine
Robotica Movil - Universidad de Guanajuato
Dr. Juan Pablo I. Ramirez Paredes <jpi.ramirez@ugto.mx>

Este pequeño ejemplo implementa un controlador en Python para el 
robot Pioneer 3dx de Adept, utilizando una maquina de estados para evadir
obstáculos



El mapa (M) se inicializa como una matriz de tamaño fijo.
La expansión se activa mediante la función expand_map_if_needed 
cuando un índice calculado (i o j), ya sea de la posición del robot
o de un punto del LIDAR, cae fuera de los límites actuales de la matriz (p. ej., i < 0).

la función añade un bloque predefinido de celdas 20
al borde correspondiente del mapa usando np.vstack (para filas) o np.hstack (para columnas). 
Las nuevas celdas se inicializan con el valor 0.5 

Para el codigo se implemento el uso de offsets dinamicos los cuales nos permiten
traducir las coordenadas absolutas y fijas del mundo (del GPS) a los índices (i, j) 
correctos de la matriz M, que está en constante crecimiento.


Cuando la expansión ocurre se añaden 20 filas es decir 2 metros ya sea "arriba,abajo,izquirda,derecha"
el offset correspondiente se incrementa en la cantidad de espacio añadido.



Cuando el robot detecta un obstáculo,
cambia a un estado de giro (1 o 2) y registra el tiempo actual.
El robot gira durante un máximo de 1.5 segundos;
si el tiempo transcurrido supera este límite,
el código lo fuerza a regresar al estado = 0 (Avanzar). 
Esto evita que el robot se quede atascado girando indefinidamente en el mismo lugar.


Ademas se le hizo algunos cambios a la maquina de estados ya que en algunas ocaciones quedaba atascada utilizando un 
 control temporal que evita que el robot quede girans
 do YA  que en algunos casos se queda girando indefinidamente por si se cruza con mas de un objeto en un lugar estrecho
 
 Si se desea ver el creciemiento del mapa cambiar el tiempo para ver como aumenta la cantidad de celdas
en la siguiente linea
    if tcurr > 1000:

"""




from controller import Robot, Motor, DistanceSensor
import matplotlib.pyplot as plt
import numpy as np
import math as m
import cv2 as cv

def v2u(v, omega):
    r = 0.5*0.195
    L = 0.35
    ur = v/r + (omega*L)/(2*r)
    ul = v/r - (omega*L)/(2*r)
    return ur, ul
    
def angdiff(t1, t2):
    angmag = m.acos(m.cos(t1)*m.cos(t2)+m.sin(t1)*m.sin(t2))
    angdir = m.cos(t1)*m.sin(t2)-m.sin(t1)*m.cos(t2)
    return m.copysign(angmag, angdir)
    
def expandMap(M, i, j, s, lrange, offset_x, offset_y):
    add_cells = 20 
    expanded = False  
    
    
    new_offset_x = offset_x
    new_offset_y = offset_y

    if i < 0:
        M = np.vstack((np.full((add_cells, M.shape[1]), 0.5), M))
        new_offset_x = offset_x + add_cells * s
        i += add_cells 
        expanded = True
        print(f"Se agregaron {add_cells} filas ARRIBA--Size: {M.shape} x-x")
    elif i >= M.shape[0]:
        M = np.vstack((M, np.full((add_cells, M.shape[1]), 0.5)))
        expanded = True
        print(f"Se agregaron {add_cells} filas ABAJO--Size: {M.shape} x-x")

    if j < 0:
        M = np.hstack((np.full((M.shape[0], add_cells), 0.5), M))
        new_offset_y = offset_y + add_cells * s
        j += add_cells 
        expanded = True
        print(f"Se agregaron {add_cells} columnas a la IZQUIERDA--Size: {M.shape}x-x")
    elif j >= M.shape[1]:
        M = np.hstack((M, np.full((M.shape[0], add_cells), 0.5)))
        expanded = True
        print(f"Se agregaron {add_cells} columnas a la DERECHA--Size: {M.shape}  x-x")

    if expanded:
        print(f"Mapa expandido 0-0: {M.shape}")

  
    return M, i, j, new_offset_x, new_offset_y


robot = Robot()
timestep = int(robot.getBasicTimeStep())

sens = []
sval = []
for idx in range(16):
    sens.append(robot.getDevice('so'+str(idx)))
    sval.append(0)
    sens[idx].enable(timestep)

leftMotor = robot.getDevice('left wheel')
rightMotor = robot.getDevice('right wheel')
gps = robot.getDevice('gps')
imu = robot.getDevice('inertial unit')
lidar = robot.getDevice('Sick LMS 291')

gps.enable(timestep)
imu.enable(timestep)
lidar.enable(timestep)
lidar.enablePointCloud()

leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# definicion inicial
M = 0.5*np.ones((30,30))
s = 0.1
lrange = 9.0


world_offset_x = 1.5
world_offset_y = 1.5

t = robot.getTime()
estado = 0              
tiempo_evasion = 0.0    
DURACION_GIRO = 1.5     

while robot.step(timestep) != -1:
    tcurr = robot.getTime()-t

    for idx in range(16):
        sval[idx] = -5.0*sens[idx].getValue()/1024.0 + 5.0
        if sval[idx] > 1.0-1e-8:
            sval[idx] = None
    
    if sval[0] or sval[1] or sval[2] or sval[3]:
        SI = True
    else:
        SI = False

    if sval[4] or sval[5] or sval[6] or sval[7]:
        SD = True
    else:
        SD = False

    # --- MÁQUINA DE ESTADO ---
    if estado == 0:
        # --- ESTADO 0: AVANZAR ---
        if SI:  
            print('Turn Right')
            estado = 2 
            tiempo_evasion = tcurr 
            v = 0.0
            omega = -1.0
        elif SD: 
            
            estado = 1  
            tiempo_evasion = tcurr 
            v = 0.0
            omega = 1.0
        else: 
            v = 0.3
            omega = 0.0
            
    elif estado == 1:
        # --- ESTADO 1: GIRANDO IZQUIERDA ---
        v = 0.0
        omega = 1.0
        if tcurr - tiempo_evasion > DURACION_GIRO:
            print('Terminó evasión, intentando avanzar -_-')
            estado = 0 

    elif estado == 2:
        # --- ESTADO 2: GIRANDO DERECHA ---
        v = 0.0
        omega = -1.0
        if tcurr - tiempo_evasion > DURACION_GIRO:
            print('Terminó evasión, intentando avanzar -_-')
            estado = 0 
    # ----------------------------------------------------

    ur, ul = v2u(v, omega)
    leftMotor.setVelocity(ul)
    rightMotor.setVelocity(ur)
    
    # --- POSICIÓN ACTUAL (usa offsets dinámicos) ---
    pos = gps.getValues()
    xg = pos[0] + world_offset_x
    yg = pos[1] + world_offset_y
    i = int(np.floor(xg/s))
    j = int(np.floor(yg/s))

    # Verifica expansión antes de escribir (pasa y recibe los offsets)
    M, i, j, world_offset_x, world_offset_y = expandMap(M, i, j, s, lrange, world_offset_x, world_offset_y)
    
    M[i,j] = 0
    rob = [i,j]

    # --- PROCESAR LIDAR  ---
    rot = imu.getRollPitchYaw()
    theta = rot[2]
    tRW = np.array(pos[:2])
    RRW = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    lval = lidar.getPointCloud()

    for k in range(len(lval)):
        if m.isfinite(lval[k].x) and m.isfinite(lval[k].y):
            if np.linalg.norm(np.array([lval[k].x, lval[k].y])) > lrange:
                break
            pR = np.array([lval[k].x, lval[k].y])
            pW = RRW @ pR + tRW
            
            # Usa los offsets dinámicos
            xg = pW[0] + world_offset_x
            yg = pW[1] + world_offset_y
            i = int(np.floor(xg/s))
            j = int(np.floor(yg/s))

            # Expansión si necesario 
            M, i, j, world_offset_x, world_offset_y = expandMap(M, i, j, s, lrange, world_offset_x, world_offset_y)
            
            cv.line(M,(rob[1], rob[0]),(j,i),(0,0,0),1)

            M[i,j] = 1
    
    if tcurr > 1000:
        break
 

leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)


h, w = M.shape


cv.line(M, (0, 0), (w - 1, 0), 1.0, 1) 
cv.line(M, (0, h - 1), (w - 1, h - 1), 1.0, 1)
cv.line(M, (0, 0), (0, h - 1), 1.0, 1)
cv.line(M, (w - 1, 0), (w - 1, h - 1), 1.0, 1)

plt.imshow(M) 
plt.show()
np.savetxt('map.txt', M)